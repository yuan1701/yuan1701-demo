This org has been deprecated in favor of the "nvd3" one:

http://github.com/nvd3/nvd3

Please go there from now on :)


